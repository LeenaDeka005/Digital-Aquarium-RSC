-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2021 at 07:04 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `darsc`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `ans_id` int(11) NOT NULL,
  `answer` varchar(300) NOT NULL,
  `q_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`ans_id`, `answer`, `q_id`) VALUES
(1, 'Salmons', 1),
(2, 'Lamprey  ', 1),
(3, 'Sharks', 1),
(4, 'Chimeras', 1),
(5, 'Fish preservation', 2),
(6, 'Crop harvesting', 2),
(7, 'Crystalisation of sugar', 2),
(8, 'Mushroom cultivation', 2),
(9, 'Sharks', 3),
(10, 'Hilsa ilisha', 3),
(11, 'Catla catla', 3),
(12, 'Rays and skates', 3),
(13, 'tiger shark', 4),
(14, 'whale', 4),
(15, 'dolphin', 4),
(16, 'rohu', 4),
(17, 'Glass Catfish', 5),
(18, 'Molly', 5),
(19, 'Labaeo', 5),
(20, 'Khuli', 5),
(21, 'blue shark', 6),
(22, 'white shark', 6),
(23, 'rainbow shark', 6),
(24, 'tiger shark', 6);

-- --------------------------------------------------------

--
-- Table structure for table `exhibit`
--

CREATE TABLE `exhibit` (
  `exhibit_id` varchar(40) NOT NULL,
  `e_name` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `phylum` varchar(40) NOT NULL,
  `found` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exhibit`
--

INSERT INTO `exhibit` (`exhibit_id`, `e_name`, `class`, `phylum`, `found`) VALUES
('Type/112', 'Mrigal Carp', 'Actinopterygii', 'Chordata', 'Rawal Lake'),
('Type/113', 'Chitala chitala', 'Actinopterygii', 'Chordata', 'Indian Rivers'),
('Type/114', 'Gourami (Osphronemidae)', 'Actinopterygii', 'Chordata', 'Fresh water lake'),
('Type/115', 'Albino shark ', ' Chondrichthyes', 'Chordata', 'Fresh Water'),
('Type/116', 'Oscar (Astronotus ocellatus)', 'Actinopterygii', 'Chordata', 'Amazon River'),
('Type/117', 'Arowana', 'Actinopterygii', 'Chordata', 'Fresh water river'),
('Type/118', 'shark', 'Actinoptery', 'chordata', 'river');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_no` int(11) NOT NULL,
  `visitor_id` varchar(50) NOT NULL,
  `query_suggestion` varchar(50) NOT NULL,
  `experience` varchar(40) NOT NULL,
  `rating` varchar(50) NOT NULL,
  `anything` varchar(100) NOT NULL,
  `f_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_no`, `visitor_id`, `query_suggestion`, `experience`, `rating`, `anything`, `f_date`) VALUES
(1001, 'Visitor/1', 'Good                        \r\n                    ', 'Very Good', '4 and a half', 'No                        \r\n                    ', '2021-07-03'),
(1002, 'Visitor/6', ' it is very good   \r\n                    ', 'Very Good', '4', ' everything is ok', '2021-08-23'),
(1003, 'Visitor/7', '    very good                    \r\n               ', 'Good', '3 and a half', 'everything is good \r\n                    ', '2021-08-23');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gallery_no` int(11) NOT NULL,
  `exhibit_id` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `image1` varchar(50) NOT NULL,
  `image2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gallery_no`, `exhibit_id`, `description`, `image1`, `image2`) VALUES
(1341, 'Type/112', 'About the Fish', '62166-images.jpg', '2639-fish1.jpg'),
(1342, 'Type/113', 'Chitla', '25643-220px.jpg', '97540-images-(1).jpg'),
(1343, 'Type/114', 'are a group of freshwater anabantiform fishes that', '75113-g1.jpg', '84058-gourami.jpg'),
(1344, 'Type/115', 'This fish is not actually a shark,but is actually ', '83965-albino1.jpg', '89596-albino-shark.jpg'),
(1345, 'Type/116', 'a species of fish from the cichlid family', '70261-oscar1.jpg', '57876-20210802_113802.jpg'),
(1346, 'Type/117', 'Arowanas are freshwater bony fish', '86850-arowana1.jpg', '37173-20210802_113812.jpg'),
(1347, 'Type/118', 'shark', '13974-20210805_110432-(1)-(1).jpg', '38021-20210805_110432-(1)-(1)-(1).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `q_id` int(11) NOT NULL,
  `question` varchar(300) NOT NULL,
  `ans_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`q_id`, `question`, `ans_id`) VALUES
(1, 'Rat fishes are:', 4),
(2, 'Smooking is used as a technique of', 5),
(3, 'Identify the edible freshwater teleost', 12),
(4, 'name a fresh water shark', 13),
(5, 'You can see right through this fish!', 17),
(6, 'what is the biggest shark', 22);

-- --------------------------------------------------------

--
-- Table structure for table `video_gallery`
--

CREATE TABLE `video_gallery` (
  `v_no` int(11) NOT NULL,
  `details` varchar(50) NOT NULL,
  `video` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video_gallery`
--

INSERT INTO `video_gallery` (`v_no`, `details`, `video`) VALUES
(1, 'African Knife Fish', '66490-african-knife.mp4'),
(2, 'Chitala Fish', '12748-chitala.mp4'),
(3, 'Parrot Fish', '93307-parrot-fish.mp4'),
(4, 'Alligator Fish', '38696-alligator.mp4'),
(5, 'Gold Fish', '72932-gold-fish.mp4'),
(6, 'Barb Fish', '48761-barb-fish.mp4'),
(7, 'Carp Fish', '85646-carp-fish.mp4'),
(8, 'Discus Fish', '62073-discus-fish.mp4'),
(9, 'Feather Fish', '14121-feather-fish.mp4'),
(10, 'Tiger Shark', '82354-tiger-shark.mp4'),
(11, 'Gourami Fish', '58808-gourami-fish.mp4'),
(12, 'Arowana Fish', '78314-arowana.mp4'),
(13, 'Oscar Fish', '80473-oscar-fish.mp4'),
(14, 'Aquirium Gallery', '39470-aquirium.mp4'),
(15, 'Feather and Oscar Fish Movement', '36401-vid-20210806-wa0000.mp4'),
(16, 'Alligator Fish eating rare video', '39392-vid-20210806-wa0005-(1).mp4'),
(17, 'Chitala Fish rare eating video', '91885-vid-20210806-wa0007.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `visitor`
--

CREATE TABLE `visitor` (
  `visitor_id` varchar(40) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `cno` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor`
--

INSERT INTO `visitor` (`visitor_id`, `name`, `address`, `cno`, `email`, `occupation`, `password`) VALUES
('Visitor/1', 'Leena', 'Guwahati', 1234554321, 'leena@gmail.com', 'Student', '12345'),
('Visitor/2', 'Shiny', 'Guwahati', 1234554321, 'shiny@gmail.com', 'Student', '12345'),
('Visitor/3', 'leena', 'noonmati', 9871234576, 'leena123@gmail.com', 'Student', 'leena@123'),
('Visitor/4', 'ram', 'noonmati', 1234567891, 'leena12@gmail.com', 'Student', 'leena@1'),
('Visitor/5', 'lee', 'zooroad', 3456217899, 'ghjdb@gmail.com', 'Student', 'www@111'),
('Visitor/6', 'deep', 'guwahati', 9924123785, 'deep12@gmail.com', 'Private Job', 'deep123'),
('Visitor/7', 'leena', 'zooroad', 9912345678, 'dee@gmail.com', 'Businessman', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`ans_id`),
  ADD KEY `qid` (`q_id`);

--
-- Indexes for table `exhibit`
--
ALTER TABLE `exhibit`
  ADD PRIMARY KEY (`exhibit_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_no`),
  ADD KEY `vid` (`visitor_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gallery_no`),
  ADD KEY `eid` (`exhibit_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `video_gallery`
--
ALTER TABLE `video_gallery`
  ADD PRIMARY KEY (`v_no`);

--
-- Indexes for table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`visitor_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `qid` FOREIGN KEY (`q_id`) REFERENCES `questions` (`q_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `vid` FOREIGN KEY (`visitor_id`) REFERENCES `visitor` (`visitor_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `eid` FOREIGN KEY (`exhibit_id`) REFERENCES `exhibit` (`exhibit_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
