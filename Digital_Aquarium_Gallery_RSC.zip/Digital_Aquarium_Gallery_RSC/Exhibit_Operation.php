  <?php
       
        include 'connection.php';
        error_reporting(1);
        if(isset($_GET['id']))
        {
            $id=$_GET['id'];
            $query=  mysqli_query($conn, "delete from exhibit where exhibit_id='$id'");
            if($query)
            {
             ?>
              <script>
                  alert("Record Deleted Successfully");
                  window.location.href="Admin_Home.php?id=e"
              </script>
        <?php
            }
           else 
           {
        ?>
             <script>
                  alert("Error In Deleting Data");
                  window.location.href="Admin_Home.php?id=e"
              </script> 
       <?php          
           } 
        }
        
        
         if(isset($_POST['edit']))
        {
           extract($_POST);
            $query=  mysqli_query($conn, "update  exhibit set e_name='" .$t2. "',class='" .$t3. "',phylum='" .$t4. "',found='" .$t5. "' where exhibit_id='$t1'");
            if($query)
            {
             ?>
              <script>
                  alert("Record Updated Successfully");
                  window.location.href="Admin_Home.php?id=e"
              </script>
        <?php
            }
           else 
           {
        ?>
             <script>
                  alert("Error In Updating Data");
                  window.location.href="Admin_Home.php?id=e"
              </script> 
       <?php          
           } 
        }
       
        
        
        
     
       
