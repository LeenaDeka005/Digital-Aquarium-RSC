<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    </head>
    <body style="background-color:lightsteelblue;">
        <br>
         <h5 align="center" style="background-color:#138496;">Gallery Details</h5>
         <?php
        include 'connection.php';
        error_reporting(1);
         $src= mysqli_query($conn, "select * from exhibit");
         $t=mysqli_query($conn,"select max(gallery_no) from gallery");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }
          else
          {
              $v=1341;
          }
        
        ?>
         <form name="form1" action="Gallery_Operation.php" method="post" enctype="multipart/form-data">
            <table align="center">
                <tr>
                    <td>
                        <label for="t1">Gallery No</label><br>
                        <input type="text" name="t1" id="t1" size="40" value="<?php echo $v; ?>" readonly>
                    </td>
                </tr>
                 <tr>
                    <td>
                        <label for="t2">Exhibit Name</label><br>
                          
                        <select class="form-control" name="t2">
                  <option value="">--Select--</option>
                <?php
                 while($s= mysqli_fetch_array($src))
                 {
                ?>
                        <option value="<?php echo $s['exhibit_id']; ?>"><?php echo $s['e_name']; ?></option>
                        
               <?php
                 }
                 ?>
                 </select>
                    </td>
                </tr>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t3">DISCRIPTION</label><br>
                        <textarea rows="4" cols="50" name="t3" required=""></textarea>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t4">Image File 1 </label><br>
                        <input type="file" name="t4" id="t4" size="40" required>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t5">Image File 2</label><br>
                        <input type="file" name="t5" id="t5" size="40" required>
                    </td>
                </tr>
                 <td colspan="2" align="center">
                        <input type="submit" class="btn btn-primary" name="save" value="Save">
                    </td>
                </tr>
            </table>
        </form>
         <hr>
            <br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
       <input  id="myInput" type="text" placeholder="Search Gallery....." size="50">
        <br>
         <table  align="center" style="width:700px;">
             <tr>
                <th>Gallery No</th>
                <th>Exhibit Id</th>
                <th>Description</th>
                <th>Image 1</th>
               <th>Image 2</th>
                <th>Delete</th>
               
            </tr>
             
         <?php
        // put your code here
       $r=mysqli_query($conn,"select * from gallery");
       while($data=mysqli_fetch_array($r))
       {
          
        ?>
       
             <tbody id="myTable">
            <tr>
                
                <td><?php echo $data['gallery_no'] ?></td>
                <td><?php echo $data['exhibit_id'] ?></td>
                <td><?php echo $data['description'] ?></td>
                <td><a href="uploads/<?php echo $data['image1'] ?>" target="_blank"><?php echo '<img src="uploads/'.$data['image1'].'" style="width:100px;height:80px;">'; ?></a></td>
                <td><a href="uploads/<?php echo $data['image2'] ?>" target="_blank"><?php echo '<img src="uploads/'.$data['image2'].'" style="width:100px;height:80px;">'; ?></a></td>
                <td><a href="Gallery_Operation.php?id=<?php echo $data['gallery_no'];?>"  onclick="return confirm('Are You Sure..You Want to Delete Data Permanently');"><img src="delete.png" hight="30px" width="30px"></a></td>
               
            </tr>
             </tbody>
       <?php } ?>
        
         </table>  
         <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>   
    </body>
</html>
