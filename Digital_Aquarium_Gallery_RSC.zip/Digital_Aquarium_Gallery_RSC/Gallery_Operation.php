<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
      <?php
        include 'connection.php';
        if(isset($_POST['save']))
        {    

            $file1 = rand(1000,100000)."-".$_FILES['t4']['name'];
            $file_loc1 = $_FILES['t4']['tmp_name'];
            $file_size1 = $_FILES['t4']['size'];
            $file_type1 = $_FILES['t4']['type'];
            $folder="uploads/";
            $new_size1 = $file_size1/1024;  
            $new_file_name1 = strtolower($file1);
            $final_file1=str_replace(' ','-',$new_file_name1);
            extract($_POST);
            
             $file2 = rand(1000,100000)."-".$_FILES['t5']['name'];
            $file_loc2 = $_FILES['t5']['tmp_name'];
            $file_size2 = $_FILES['t5']['size'];
            $file_type2 = $_FILES['t5']['type'];
            $new_size2 = $file_size2/1024;  
            $new_file_name2 = strtolower($file2);
            $final_file2=str_replace(' ','-',$new_file_name2);
            extract($_POST);
            
            
if(move_uploaded_file($file_loc1,$folder.$final_file1) && move_uploaded_file($file_loc2,$folder.$final_file2))
 {
  $sql="INSERT INTO gallery values('$t1','$t2','$t3','$final_file1','$final_file2')";
mysqli_query($conn,$sql);
  ?>
<script>
alert('Galary Details Uploaded Successfully');
window.location.href='Admin_Home.php?id=g';
</script>
<?php
 }
else
 {
  ?>
<script>
alert('Error while Uploading file');
window.location.href='Admin_Home.php?id=g';
</script>
<?php
 }
}




 if(isset($_GET['id']))
        {
            $id=$_GET['id'];
            $query=  mysqli_query($conn, "delete from gallery where gallery_no='$id'");
            if($query)
            {
             ?>
              <script>
                  alert("Record Deleted Successfully");
                  window.location.href="Admin_Home.php?id=g"
              </script>
        <?php
            }
           else 
           {
        ?>
             <script>
                  alert("Error In Deleting Data");
                  window.location.href="Admin_Home.php?id=g"
              </script> 
       <?php          
           } 
        }

?>

    </body>
</html>
