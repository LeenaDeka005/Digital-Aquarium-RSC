<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
   session_start();
   error_reporting(1);
   include 'Connection.php';
 // if(!isset($_SESSION['uid']))
 //  {
 //  	header('location:index.php');
 //  }
   //     $uid= $_SESSION['uid'];
        
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Digital Aquarium</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap.min.css">
        <script src="jquery.slim.min.js"></script>
        <script src="bootstrap.bundle.min.js"></script>
        <style type="text/css">
         .carousel-item {
  height: 100vh;
  min-height: 350px;
  background: no-repeat center center scroll;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
      </style>
      <style type="text/css">
            #header{
    height:140px;
    background: white;
   
}
#menu1{
    height: 20px;
    background: brown;
}
 .home{
                       position:absolute;
                       top:50px;
                        left:20px;
                        font-size:18px;
                        font-family: serif;
                        font-style: italic;
                            font-weight: bold;
                    }
                    .home1{
                       position:absolute;
                       top:40px;
                        left:550px;
                        font-size:28px;
                        font-family: serif;
                        font-style: italic;
                    }
                    .home2{
                       position:absolute;
                       top:60px;
                        left:850px;
                       
                        font-style: italic;
                    }
                    

        </style>
    </head>
    <body>
         <div class="home" style="color:grey;"> 
             <img src="images/fish.png" height="110px" width="110px">
   </div>
      <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background-color:#494f54;">
  <div class="container">
    <a class="navbar-brand" href="#" style="color:lightsalmon; "> Digital Aquarium, RSC Guwahati, Asssam</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
            <a class="nav-link" href="Admin_Home.php" style="color:wheat;">Home
                <span class="sr-only">(current)</span>
              </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="Admin_Home.php?id=e" style="color:yellowgreen;">Exhibits</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Admin_Home.php?id=g" style="color:yellowgreen;">Gallery</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="Admin_Home.php?id=q" style="color:yellowgreen;">Quiz Question</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="Admin_Home.php?id=vf" style="color:yellowgreen;">View Feedback</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="Admin_Home.php?id=vg" style="color:yellowgreen;">Video Gallery</a>
        </li>
       
      </ul>
    </div>
  </div>
</nav>
      <br>
      <br>
     
      

     
<header>
     
      <?php
                            @$id=$_REQUEST['id'];
				if($id!="")
				{
				if($id=="e")
				{
					include('Exhibit_Details.php');
					}
				elseif($id=="g")
				{
					include('Gallery.php');
					}
					
				elseif($id=="q")
				{
					include('Quiz_Question.php');
				}
                                elseif($id=="ae")
				{
					include('Answer_Entry.php');
				}
                               elseif($id=="vf")
				{
					include('View_Feedback.php');
				}
                                elseif($id=="vg")
				{
					include('Video_Gallery.php');
				}
                                }
				else
				{
				?>
     <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('back1.jpg')">
        <div class="carousel-caption d-none d-md-block">
         
        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('back2.jpg')">
        <div class="carousel-caption d-none d-md-block">
         
          
        </div>
      </div>
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('back3.png')">
        <div class="carousel-caption d-none d-md-block">
         

</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
    
    
             
<?php }
?>
     

   
</header>

<!-- Page Content -->
<section class="py-5">
  <div class="container">
    <h4 class="display-4" align="center" style="color:green;">Digital Aquarium</h4>
    <p class="lead" align="center" style="color:#e83e8c;">RSC Guwahati </p>
  </div>
</section>
    </body>
</html>
