<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
     <?php
    error_reporting(1);
    include 'connection.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <title></title>
         
    </head>
    <body>
         <?php
         $t=mysqli_query($conn,"select max(v_no) from video_gallery");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }else
          {
              $v=1;
          }
        ?>
        <br>
         <h3 align="center" style="color:green;">Video Gallery Entry Form</h3>
          <hr>
          <form name="form1" action="Video_Gallery_Operation.php" method="post" enctype="multipart/form-data">
        <table  align="center"  style="width:400px;">
            <tr>
                <td>
                    <label>Video No</label>
                </td>
                <td>
                    <input type="text"  name="t1" value="<?php echo $v; ?>" readonly size="40">
                </td>
            </tr>
             <tr>
                <td>
                    <label>Details</label>
                </td>
                <td>
                    <input type="text"  name="t2" required size="40">
                </td>
            </tr>
             
             <tr>
                <td>
                    <label> Video File</label>
                </td>
                <td>
                    <input type="file"  name="t3" required size="40">
                </td>
            </tr>
             <tr>
                 <td></td>
                <td>
                    <input type="submit" class="btn btn-primary form-control"  name="save" value="Save">
                </td>
                
            </tr>
        </table>
              
             
  
 
        <br>
        <table align="center" style="width:700px;">
        <thead>
             <tr>
                <th>Video No</th>
                <th>Details</th>
                 <th>Video</th>
                <th>Delete</th>
               
            </tr>
        </thead>     
         <?php
        // put your code here
        error_reporting(1);
        include 'connection.php';
        extract($_POST);
        $r=mysqli_query($conn,"select * from video_gallery");
       while($data=mysqli_fetch_array($r))
       {
          
        ?>
        <tbody id="myTable">
           
            <tr>
                 <td> <?php echo $data['v_no'] ?></td>
                  <td> <?php echo $data['details'] ?></td>
                  <td><video controls="" height="50" width="50">
                    <?php echo '<source src="uploads/'.$data['video'].'" type="video/mp4" />' ;?>
                         <?php echo '<source src="uploads/'.$data['video'].'" type="video/wmv" />' ;?>
                          </video></a></td>
                 
                          
                    
                  <td><a href="Video_Gallery_Operation.php?id=<?php echo $data['v_no'];  ?>"><img src="delete.png" hight="20px" width="20px"></a> </td>
                      
               
               
            </tr>
        </tbody>
       <?php } ?>
        
         </table>
      
        
              
              
    </body>
</html>
