<?php
   session_start();
   error_reporting(1);
   include 'Connection.php';
  if(!isset($_SESSION['vid']))
   {
   	header('location:Home.php');
   }
        $vid= $_SESSION['vid'];
        $s= mysqli_query($conn, "select * from visitor where visitor_id='$vid'");
        $r= mysqli_fetch_array($s);
        $name=$r['name']; 
?>
<!DOCTYPE html>
<html>
   <head>
      <title></title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
      <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="style.css">
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
      <style type="text/css">
         .animateuse{
         animation: leelaanimate 0.5s infinite;
         }
         @keyframes leelaanimate{
         0% { color: red },
         10% { color: yellow },
         20%{ color: blue }
         40% {color: green },
         50% { color: pink }
         60% { color: orange },
         80% {  color: black },
         100% {  color: brown }
         }
      </style>
   </head>
   <body>
                
      
      <div>
      
          <h4 align="center" style="background-color:#343a40;color:yellowgreen;">Welcome <?php echo $name; ?> to  RSC Online Quiz on Fish Species </h4><br>
      <div class="container ">
         <div class="container">        
           <div class="col-lg-8 d-block m-auto bg-light quizsetting ">
              
               <form action="checked.php" method="post">
                  <?php
                    $t=mysqli_query($conn,"select count(q_id) from questions");
                   $row=  mysqli_fetch_array($t);
                   $count=$row[0];
                     for($i=1;$i<=$count;$i++){
                     $l = 1;
                  
                     $ansid = $i;

                     $sql1 = "SELECT * FROM `questions` WHERE `q_id` = $i ";
                     	$result1 = mysqli_query($conn, $sql1);
                     		if (mysqli_num_rows($result1) > 0) {
                     		while($row1 = mysqli_fetch_array($result1)) {
                     	?>				
                 
                  <div class="card bg-dark text-white" style="width: 50rem;">
                    
                     <p class="card-header">  <?php echo $i ." : ". $row1['question']; ?> </p>
                    
                     <?php
                       $sql = "SELECT * FROM `answers` WHERE `q_id` = $i"; 
                        	$result = mysqli_query($conn, $sql);
                        		if (mysqli_num_rows($result) > 0) {
                        						while($row = mysqli_fetch_array($result)) {
                        	?>	
                           
                     <div class="card-block">
                        <input type="radio" name="quizcheck[<?php echo $ansid; ?>]" id="<?php echo $ansid; ?>" value="<?php echo $row['ans_id']; ?>" > <?php echo $row['answer']; ?> 
                        <br>
                     </div>
                     <?php
                        
                        } } 
                        $ansid = $ansid + $l;
                        } }}
                        
                     ?>
                  </div>

                  <br>
                  <input type="submit" name="submit" Value="Submit" class="btn btn-success m-auto d-block" /> <br>
               </form>
               <p id="letc"></p>
            </div>
            <br>
           
         </div>
         <br>
        
      </div>


    
        </ul>
      </div>



   </body>
</html>
