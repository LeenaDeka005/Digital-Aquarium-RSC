<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <link rel="stylesheet" href="bootstrap.min.css">
        <script src="jquery.slim.min.js"></script>
        <script src="bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <br>
        <br>
        <br>
        <form name="form1" action="" method="post">
        <table class="table" align="center" style="width:500px;">
            <tr>
                <td>Start Date:<input type="date" name="t1" required></td>
                <td>To Date:<input type="date" name="t2" required></td>
                <td>Search:<input class="btn btn-success" type="submit" name="src" value="Search"></td>
            </tr>
        </table> 
            </form
        <hr>
        <?php
          error_reporting(1);
         include 'Connection.php';
         if(isset($_POST['src']))
        {
            extract($_POST); 
       
            ?>
         <h3 align="center">Feedback Given by Visitor</h3>
             
         <table align="center" class="table" style="width:900px;">
             <tr>
                 <th colspan="4"><input  id="myInput" type="text" placeholder="Search Feedback.." size="50"></th> </tr>
             <tr>
                 
                <th align="center" >Feedback No</th>
                <th align="center" >Feedback</th>
                <th align="center" >Experience</th>
                <th align="center" >Rating</th>
                 <th align="center" >Any Suggestion</th>
                <th align="center" >Feedback Date</th>
               
               
            </tr>
       
         <?php
       
      
       $r=mysqli_query($conn,"select * from feedback where f_date between '$t1' and '$t2'");
       while($data=mysqli_fetch_array($r))
       {
          
        ?>
        <tbody id="myTable">
           
            <tr>
                
                <td><?php echo $data['feedback_no'] ?></td>
                <td><?php echo $data['query_suggestion'] ?></td>
                <td><?php echo $data['experience'] ?></td>
                <td><?php echo $data['rating'] ?></td>
                <td><?php echo $data['anything'] ?></td>
                 <td><?php echo $data['f_date'] ?></td>
               
               
            </tr>
        </tbody>
       <?php } ?>
        
         </table>   
        <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>   
        
        
        <?php    
         }
         else
         { ?>
              <h3 align="center">Feedback Given by Visitor</h3>
             
         <table align="center" class="table" style="width:900px;">
             <tr>
                 <th colspan="4"><input  id="myInput" type="text" placeholder="Search Feedback.." size="50"></th> </tr>
             <tr>
                 
                <th align="center" >Feedback No</th>
                <th align="center" >Feedback</th>
                <th align="center" >Experience</th>
                <th align="center" >Rating</th>
                 <th align="center" >Any Suggestion</th>
                <th align="center" >Feedback Date</th>
               
               
            </tr>
       
         <?php
       
      
       $r=mysqli_query($conn,"select * from feedback");
       while($data=mysqli_fetch_array($r))
       {
          
        ?>
        <tbody id="myTable">
           
            <tr>
                
                <td><?php echo $data['feedback_no'] ?></td>
                <td><?php echo $data['query_suggestion'] ?></td>
                <td><?php echo $data['experience'] ?></td>
                <td><?php echo $data['rating'] ?></td>
                <td><?php echo $data['anything'] ?></td>
                 <td><?php echo $data['f_date'] ?></td>
               
               
            </tr>
        </tbody>
       <?php } ?>
        
         </table>   
        <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>   
             
             
        <?php     
         }
        ?>
      
    </body>
</html>
