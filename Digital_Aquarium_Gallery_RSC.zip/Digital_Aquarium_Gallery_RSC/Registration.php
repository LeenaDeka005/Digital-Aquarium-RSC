<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Digital Aquarium</title>
   <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/slidefolio.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/css">
           
 .home{
                       position:absolute;
                       top:150px;
                        left:950px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    }
                  .home1{
                       position:absolute;
                       top:180px;
                        left:1150px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    } 
                     .home2{
                       position:absolute;
                       top:700px;
                        left:220px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    } 
                     .home3{
                       position:absolute;
                       top:10px;
                        left:120px;
                       
                    } 
                    .home4{
                       position:absolute;
                       top:20px;
                        left:410px;
                       
                    } 
                    .home5{
                       position:absolute;
                       top:20px;
                        left:510px;
                       
                    } 
        </style>
         <style type="text/css">
             input[type=text], input[type=password],input[type=date], input[type=email],select,input[type=file]{
	width: 320px;
	height: 35px;
	background: transparent;
	border: 1px solid green;
	border-radius: 2px;
	color: black;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}
  textArea{
	width: 420px;
	height: 100px;
	background: transparent;
	border: 1px solid black;
	border-radius: 2px;
	color: #004085;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}
input[type=submit],input[type=button]{
	width: 320px;
	height: 40px;
	background: #004085;
	border: 1px solid #fff;
	cursor: pointer;
	border-radius: 2px;
	color: #040505;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 6px;
	margin-top: 10px;
}
input[type=submit]:hover{
	
        color: white;
}

 input[type=submit]:active{
	opacity: 0.6;
}
th, td {
               
                padding:6px
              
            }

        </style>
           <style>
  .required:after {
    content:" *";
    color: red;
  }
</style>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  </head>
  <body>
       
	  <div id="nav">
    <!-- Navigation -->
    <nav class="navbar navbar-new" role="navigation">
   <div class="container">
  <!-- Brand and toggle get grouped for better mobile display -->
 
  <div class="collapse navbar-collapse" id="mobilemenu">

	  <ul class="nav navbar-nav navbar-right text-center">
              <li><a href="index.php"><i class="service-icon fa fa-home"></i>&nbsp;Home</a></li>
             <li><a href="View_Gallery.php"><i class="service-icon fa fa-camera"></i>&nbsp;Gallery</a></li>
               <li><a href="View_Video_Gallery.php"><i class="service-icon fa fa-camera"></i>&nbsp;Video Gallery</a></li>
                  <li><a href="Fun_Facts.php"><i class="service-icon fa fa-camera"></i>Fun Facts</a></li>
               <li><a href="Registration.php"><i class="service-icon fa fa-envelope"></i>&nbsp;Registration</a></li>
                <li><a href="Login.php">Login</a></li>
    </ul>
  </div><!-- /.navbar-collapse -->
  </div>
</nav>
    <!-- /Navigation -->
</div>	
    <!-- About -->
    <div id="about" class="about_us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 text-center">
            <h2>Visitor Registration</h2>
             <?php
        include 'Connection.php';
        error_reporting(1);
         $t=mysqli_query($conn,"select max(visitor_id) from visitor");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }
          else
          {
              $v='Visitor/1';
          }
        
        ?>
       <form name="form1" action="" method="post">
            <table align="center">
                <tr>
                    <td>
                        <label for="t1">VISITOR ID(Remember Your ID)</label><br>
                        <input type="text" name="t1" id="t1" size="40" value="<?php echo $v; ?>" readonly>
                    </td>
                </tr>
                 <tr>
                    <td>
                        <label for="t2">VISITOR NAME</label><br>
                        <input type="text" name="t2" id="t2" size="40" required>
                    </td>
                </tr>
                <tr>
                     <td>
                        <label for="t3">ADDRESS</label><br>
                        <textarea rows="4" cols="43" name="t3" required=""></textarea>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t4">PHONE NUMBER</label><br>
                       <input type="tel" name="t4" id="t4" size="40" pattern="^\d{10}$" required >
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t5">Email</label><br>
                        <input type="email" name="t5" id="t5" size="40" required>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t6">Occupation</label><br>
                        <select name="t6" required="">
                            <option value="">--Select--</option>
                            <option value="Student">Student</option>
                            <option value="Research Scholar">Research Scholar</option>
                            <option value="Businessman">Businessman</option>
                            <option value="Government Job">Government Job</option>
                            <option value="Private Job">Private Job</option>
                            <option value="Others">Others</option>
                        </select>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t7">Password</label><br>
                        <input type="password" name="t7" id="t7" size="40" required>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" class="btn btn-primary" name="save" value="Save">
                    </td>
                </tr>
            </table>
        </form>
         <?php 
        if(isset($_POST['save']))
        {
         extract($_POST);
        $r= mysqli_query($conn, "insert into visitor values('$t1','$t2','$t3','$t4','$t5','$t6','$t7')") or die("Error in Saving Data");
        if($r)
        {
        ?>
        <script>
            alert("Record Saved Successfully");
            window.location.href="index.php?id=l";
         </script>   
        <?php
        }
        }
        ?>
      
          </div>
        </div>
	  </div>
    </div>
    <!-- /About -->
    <!-- Services -->
    <div id="services" class="services">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2>Our Collections</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-camera-retro fa-3x"></i>
              <h3>Science Museum</h3>
                <h3>Aquarium</h3>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
			<i class="service-icon fa fa-camera fa-3x"></i>
              <h3>Mirror Gallery</h3>
                <h3>Colamine</h3>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-globe fa-3x"></i>
              <h3>Butterfly Park</h3>
                <h3>Aromatic Plant Garden</h3>
              <p></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /Services -->

    <!-- Portfolio -->
     <div id="portfolio" class="portfolio">
    <div class="container">
    <div class="row push50">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2>Our Gallery</h2>
			<h3>
			<span class="filter label label-default" data-filter="all">ALL</span>
	<span class="filter label label-default" data-filter="bw">Indian</span>
	<span class="filter label label-default" data-filter="nature">Imported</span>
	
	</h3>
            <hr>
          </div>
        </div>
		
		<div class="row">
		
		<div class="gallery">
		
    		  <ul id="Grid" class="gcontainer">
    		    <li class="col-md-4 col-sm-4 col-xs-12 mix bw portraits" data-cat="graphics">
              <a data-toggle="modal" data-target="#portrait1" class="mix-cover">
                  <img class="horizontal" src="img/back1.jpg" alt="placeholder">
      		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 1</span></span>
              </a>                
      		  </li>
    		    <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="graphics">
                <a data-toggle="modal" data-target="#portrait2" class="mix-cover">
                    <img class="horizontal" src="img/rsc.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 2</span></span>
                </a>                
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix nature" data-cat="nature">
                <a data-toggle="modal" data-target="#portrait3" class="mix-cover">
                    <img class="horizontal" src="img/img13.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 3</span></span>
        		    </a>
      		  </li>
      		  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portraits">
                <a data-toggle="modal" data-target="#portrait4" class="mix-cover">
                    <img class="horizontal" src="img/img14.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 4</span></span>
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portraits">
                <a data-toggle="modal" data-target="#portrait5" class="mix-cover">
                    <img class="horizontal" src="img/img15.jpg" alt="placeholder">
        		       <span class="overlay"><span class="valign"></span><span class="title">Aqua 4</span></span>
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix nature" data-cat="nature">
                <a data-toggle="modal" data-target="#portrait6" class="mix-cover">
                    <img class="horizontal" src="img/img14.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 5</span></span>
        		    </a>
      		  </li>
      		  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portrait">
                <a data-toggle="modal" data-target="#portrait7" class="mix-cover green">
                    <img class="vertical" src="img/img13.jpg" alt="portrait 4">
                  <span class="overlay"><span class="valign"></span><span class="title">Aqua 6</span></span>           
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix bw nature all" data-cat="portrait">
                <a data-toggle="modal" data-target="#portrait8" class="mix-cover green">
                    <img class="vertical" src="img/img15.jpg" alt="Forest">
                   <span class="overlay"><span class="valign"></span><span class="title">Aqua 7</span></span>                    
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix bw nature all" data-cat="bw">
                <a data-toggle="modal" data-target="#portrait19" class="mix-cover green">
                    <img class="vertical" src="img/img14.jpg" alt="Black and White">
                   <span class="overlay"><span class="valign"></span><span class="title">Aqua 8</span></span>                  
        		    </a>
      		  </li>
    		  </ul>   
			  
<!-- Load Photo in Modal -->			  
   <div class="modal fade" id="portrait1" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 1</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait1" src="img/back1.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="portrait2" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 2</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait2" src="img/rsc.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="portrait3" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 3</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait3" src="img/back1.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->














<!-- /Load Photo in Modal -->	
		</div>	
      </div>
		</div>
      </div>
    <!-- /Portfolio -->
    <!-- Contact -->
    <div id="contact">
      <div class="container">
        <div class="row">
		
          <div class="col-md-1 col-md-offset-1">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14329.354514989252!2d91.8160587!3d26.1204997!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1324cdcc1795214b!2sSCIENCE%20MUSEUM!5e0!3m2!1sen!2sin!4v1628174370763!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
             <div class="col-md-5 col-md-offset-5">
		<img src="images/contact.JPG" width="450" height="450">
          </div>
        </div>
      </div>
    </div>
    <!-- /Contact -->
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 text-center">
           <h2>Thank You</h2>
           <em>Copyright &copy; 2021 Design By, Leena Deka</em>
          </div>
        </div>
      </div>
    </footer>
    <!-- /Footer -->
    <!-- Bootstrap core JavaScript -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-scrolltofixed-min.js"></script>
	<script src="js/jquery.vegas.js"></script>
	<script src="js/jquery.mixitup.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/bootstrap.js"></script>
	
<!-- Slideshow Background  -->
	<script>
$.vegas('slideshow', {
  delay:5000,
  backgrounds:[
     { src:'./img/back1.jpg', fade:3000 },
	 { src:'./img/rsc.jpg', fade:3000 }
   
	
   
  	
	   
  ]
})('overlay', {
src:'./img/1overlay.png'
});

	</script>
<!-- /Slideshow Background -->

<!-- Mixitup : Grid -->
    <script>
		$(function(){
    $('#Grid').mixitup();
      });
    </script>
<!-- /Mixitup : Grid -->	

    <!-- Custom JavaScript for Smooth Scrolling - Put in a custom JavaScript file to clean this up -->
    <script>
      $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
          if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
            || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
              $('html,body').animate({
                scrollTop: target.offset().top
              }, 1000);
              return false;
            }
          }
        });
      });
    </script>
<!-- Navbar -->
<script type="text/javascript">
$(document).ready(function() {
        $('#nav').scrollToFixed();
  });
    </script>
<!-- /Navbar-->
	
  </body>

</html>