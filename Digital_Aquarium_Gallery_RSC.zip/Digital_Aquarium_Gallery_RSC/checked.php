<?php
   session_start();
   error_reporting(1);
   include 'Connection.php';
  if(!isset($_SESSION['vid']))
   {
   	header('location:Home.php');
   }
        $vid= $_SESSION['vid'];
        $s= mysqli_query($conn, "select * from visitor where visitor_id='$vid'");
        $r= mysqli_fetch_array($s);
        $name=$r['name']; 
?>
<!DOCTYPE html>
<html>
   <head>
      <title></title>
      <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<style type="text/css">
	.animateuse{
			animation: leelaanimate 0.5s infinite;
		}

@keyframes leelaanimate{
			0% { color: red },
			10% { color: yellow },
			20%{ color: blue }
			40% {color: green },
			50% { color: pink }
			60% { color: orange },
			80% {  color: black },
			100% {  color: brown }
		}
</style>
<script type="text/javascript">
			function closeCurrentTab(){
				var conf=confirm("Are you sure, you want to close this tab?");
				if(conf==true){
					close();
				}
			}
		</script>
   </head>
   <body>
     <div class="container text-center" >
     	<br><br>
    
    	
      <table class="table text-center table-bordered table-hover">
      	<tr>
      		<th colspan="2" class="bg-dark"> <h1 class="text-white"> Your Score <?php echo $name; ?> </h1></th>
      		
      	</tr>
      	<tr>
		      	<td>
		      		Questions Attempted
		      	</td>

	         <?php
            $counter = 0;
            $Resultans = 0;
            if(isset($_POST['submit'])){
            if(!empty($_POST['quizcheck'])) {
            // Counting number of checked checkboxes.
            $checked_count = count($_POST['quizcheck']);
            // print_r($_POST);
            ?>

        	<td>
            <?php
            echo "You have attempt ".$checked_count." option."; ?>
            </td>
        
          	
            <?php
            // Loop to store and display values of individual checked checkbox.
            $selected = $_POST['quizcheck'];
            
            $q1= " select * from questions ";
            $ansresults = mysqli_query($conn,$q1);
            $i = 1;
            while($rows = mysqli_fetch_array($ansresults)) {
              // print_r($rows);
            	$flag = $rows['ans_id'] == $selected[$i];
            	
            			if($flag){
            				// echo "correct ans is ".$rows['ans']."<br>";				
            				$counter++;
            				$Resultans++;
            				// echo "Well Done! your ". $counter ." answer is correct <br><br>";
            			}else{
            				$counter++;
            				// echo "Sorry! your ". $counter ." answer is innncorrect <br><br>";
            			}					
            		$i++;		
            	}
            	?>
            	
    		
    		<tr>
    			<td>
    				Your Total score
    			</td>
    			<td colspan="2">
	    	<?php 
	            echo " Your score is ". $Resultans.".";
	            }
	            else{
	            echo "<b>Please Select Atleast One Option.</b>";
	            }
	            } 
	          ?>
	          </td>
            </tr>
        </table>
 <table class="table" style="text-align: left;">
             <tr>
                <th>Question No</th>
                <th>Question</th>
                <th>Correct Answer</th>
                 
            </tr>
         <?php
          $temp= mysqli_query($conn, "select * from questions");
          while($data=mysqli_fetch_array($temp))
          {
              $aid=$data['ans_id'];
              $temp1= mysqli_query($conn, "select * from answers where ans_id=$aid");
              $data1=mysqli_fetch_array($temp1)
        ?>   
            <tr>
                <td><?php echo $data['q_id']; ?> </td>
                <td><?php echo $data['question']; ?></td>
                <td><?php echo $data1['answer']; ?></td>               
            </tr>
            
       <?php    
          }
            
        ?>    
        </table>
       
        <a href="Home.php" class="btn btn-success">Home</a>
       
      </div>
       <script type="text/javascript">
       function close_window() {
  if (confirm("Close Window?")) {
    window.top.close();
  }
}
</script>
   </body>
</html>



