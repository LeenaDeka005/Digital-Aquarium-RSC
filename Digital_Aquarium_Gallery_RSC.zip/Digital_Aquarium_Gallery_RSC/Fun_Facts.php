<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Digital Aquarium</title>
   <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/slidefolio.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/css">
           
 .home{
                       position:absolute;
                       top:150px;
                        left:950px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    }
                  .home1{
                       position:absolute;
                       top:180px;
                        left:1150px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    } 
                     .home2{
                       position:absolute;
                       top:700px;
                        left:220px;
                        font-size:22px;
                        font-family: serif;
                        font-style: italic;
                        font-weight: bold;
                    } 
                     .home3{
                       position:absolute;
                       top:10px;
                        left:120px;
                       
                    } 
                    .home4{
                       position:absolute;
                       top:20px;
                        left:410px;
                       
                    } 
                    .home5{
                       position:absolute;
                       top:20px;
                        left:510px;
                       
                    } 
        </style>
         <style type="text/css">
             input[type=text], input[type=password],input[type=date], input[type=email],select,input[type=file]{
	width: 320px;
	height: 35px;
	background: transparent;
	border: 1px solid green;
	border-radius: 2px;
	color: black;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}
  textArea{
	width: 420px;
	height: 100px;
	background: transparent;
	border: 1px solid black;
	border-radius: 2px;
	color: #004085;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}
input[type=submit],input[type=button]{
	width: 320px;
	height: 40px;
	background: #004085;
	border: 1px solid #fff;
	cursor: pointer;
	border-radius: 2px;
	color: #040505;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 6px;
	margin-top: 10px;
}
input[type=submit]:hover{
	
        color: white;
}

 input[type=submit]:active{
	opacity: 0.6;
}
th {
               
                padding:6px;
                color:brown;
                 font-size:20px;
                
            }
td {
               
                padding:6px;
                color:green;
                font-size:18px;
                list-style-type: square;
            }
        </style>
           <style>
  .required:after {
    content:" *";
    color: red;
  }
</style>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  </head>
  <body>
       
	  <div id="nav">
    <!-- Navigation -->
    <nav class="navbar navbar-new" role="navigation">
   <div class="container">
  <!-- Brand and toggle get grouped for better mobile display -->
 
  <div class="collapse navbar-collapse" id="mobilemenu">

	  <ul class="nav navbar-nav navbar-right text-center">
              <li><a href="index.php"><i class="service-icon fa fa-home"></i>&nbsp;Home</a></li>
             <li><a href="View_Gallery.php"><i class="service-icon fa fa-camera"></i>&nbsp;Gallery</a></li>
               <li><a href="View_Video_Gallery.php"><i class="service-icon fa fa-camera"></i>&nbsp;Video Gallery</a></li>
                  <li><a href="Fun_Facts.php"><i class="service-icon fa fa-camera"></i>Fun Facts</a></li>
               <li><a href="Registration.php"><i class="service-icon fa fa-envelope"></i>&nbsp;Registration</a></li>
                <li><a href="Login.php">Login</a></li>
    </ul>
  </div><!-- /.navbar-collapse -->
  </div>
</nav>
    <!-- /Navigation -->
</div>	
    <!-- About -->
    <div id="about" class="about_us">
      <div class="container">
        <div class="row">
        <div class="col-md-8 col-md-offset-2 text-center">
            <h2>Fun Facts</h2>
        </div>
            <table align="center" style="width:1000px;">
                <tr>
                    <th style="color:brown;">FEATHER FISH </th>
                </tr>
                <tr>
                    <td>Feather fish are Nocturnal. They are a weakly electric fish which use an electric organ and receptors distributed over the length of their body in order to locate insect larvae.</td>
                </tr>
                <tr>
                    <td>They are Peculiar. They can move forward and backward with the help of their fins.</td>
                </tr>
                <tr>
                    <td>They may sleep or take rest horizontally as well as in perpendicular position.</td>
                </tr>
                <tr>
                    <th>CHITALA FISH </th>
                    
                </tr>
                 <tr>
                    <td>Chital fish is a carnivorous fish. They are generally a fish eater of freshwater. They live in clean water of river, swamp etc.</td>
                </tr>
                <tr>
                    <td>They generally eat feed from lower level of water. Along with this they also eat feed from other water level. Various types of small fish, shrimp, snail, and aquatic insects are the favourite feed of this freshwater fish.</td>
                </tr>
                 <tr>
                    <td>During breeding period they make hole by digging soil.</td>
                </tr>
                 <tr>
                    <th>ALLIGATOR FISH </th>
                    
                </tr>
                 <tr>
                    <td>Looks like an alligator.</td>
                </tr>
                <tr>
                    <td>It gets its name from its broad snout, which resembles that of the American alligator. Also like the alligator, this species reaches impressive sizes.</td>
                </tr>
                 <tr>
                    <td>This species is what researchers call a “living fossil.” This means that fossils of this fish, even those from millions of years ago, look incredibly similar to the living animal today.</td>
                </tr>
                 <tr>
                    <td>In the constant search for something to eat, it helps to be flexible. This fish can hunt for prey in both fresh and saltwater habitats, which makes them euryhaline.</td>
                </tr>
                 <tr>
                    <td>When they gulp air from the surface, it doesn’t go to lungs, but to their swim bladder. The swim bladder acts like a lung, and also helps them regulate their buoyancy.</td>
                </tr>
                 <tr>
                    <th>OSCAR FISH </th>
                    
                </tr>
                 <tr>
                    <td>Particularly in wild individuals, you will notice this fish has small round spots on its fins. These spots, known as “ocelli, or “eye spots,” look similar to eyes. Researchers believe that the eye spots help deter predators.</td>
                </tr>
                <tr>
                    <td>While fin nipping doesn’t kill the fish, it does impact their overall survival ability. Those fish who suffer from the nibbling of piranhas often grow more slowly, and sometimes their fins become infected.</td>
                </tr>
                 <tr>
                    <td>Like many cichlids, this species protects its young from predators. They keep the eggs clean, move the newly hatched young, and protect the young fry.</td>
                </tr>
                 <tr>
                    <td>One pair of male and female make their territory during breeding.</td>
                </tr>
                  <tr>
                    <th>ALBINO SHARK </th>
                    
                </tr>
                 <tr>
                    <td>Striking coloration</td>
                </tr>
                <tr>
                    <td>Will not eat ornamental plants</td>
                </tr>
                 <tr>
                    <td>Generally peaceful disposition with fish and peaceful larger invertebrates</td>
                </tr>
                 <tr>
                    <td>Very active and noticeable fish in any aquarium</td>
                </tr>
                <tr>
                    <td>Very Hardy</td>
                </tr>
                  <tr>
                    <th>FISH EVOLUTION </th>
                    
                </tr>
                 <tr>
                    <td>The evolution of fish began about 530 million years ago during the Cambrian explosion. It was during this time that the early chordates developed the skull and the vertebral column, leading to the first craniates and vertebrates. The first fish lineages belong to the Agnatha, or jawless fish.</td>
                </tr>
                <tr>
                    <td>Early examples include Haikouichthys. During the late Cambrian, eel-like jawless fish called the conodonts, and small mostly armoured fish known as ostracoderms, first appeared. Most jawless fish are now extinct; but the extant lampreys may approximate ancient pre-jawed fish. Lampreys belong to the Cyclostomata, which includes the extant hagfish, and this group may have split early on from other agnathans.</td>
                </tr>
                 <tr>
                    <td>The earliest jawed vertebrates probably developed during the late Ordovician period. They are first represented in the fossil record from the Silurian by two groups of fish: the armoured fish known as placoderms, which evolved from the ostracoderms; and the Acanthodii (or spiny sharks). The jawed fish that are still extant in modern days also appeared during the late Silurian: the Chondrichthyes (or cartilaginous fish) and the Osteichthyes (or bony fish). The bony fish evolved into two separate groups: the Actinopterygii (or ray-finned fish) and Sarcopterygii (which includes the lobe-finned fish).</td>
                </tr>
                 <tr>
                    <th>FISH PHYSIOLOGY </th>
                    
                </tr>
                 <tr>
                    <td>Fish physiology is the scientific study of how the component parts of fish function together in the living fish.[2] It can be contrasted with fish anatomy, which is the study of the form or morphology of fishes. In practice, fish anatomy and physiology complement each other, the former dealing with the structure of a fish, its organs or component parts and how they are put together, such as might be observed on the dissecting table or under the microscope, and the later dealing with how those components function together in the living fish.</td>
                </tr>
                <tr>
                    <td>Most fish exchange gases using gills on either side of the pharynx (throat). Gills are tissues which consist of threadlike structures called filaments.</td>
                </tr>
                 <tr>
                    <td>Fish from multiple groups can live out of the water for extended time periods. Amphibious fish such as the mudskipper can live and move about on land for up to several days, or live in stagnant or otherwise oxygen depleted water. Many such fish can breathe air via a variety of mechanisms.</td>
                </tr>
                 <tr>
                    <td>Air breathing fish can be divided into obligate air breathers and facultative air breathers. Obligate air breathers, such as the African lungfish, are obligated to breathe air periodically or they suffocate. Facultative air breathers, such as the catfish Hypostomus plecostomus, only breathe air if they need to and can otherwise rely on their gills for oxygen.</td>
                </tr>
               
                
            </table>
         
        </div>
	  </div>
    </div>
    <!-- /About -->
    <!-- Services -->
    <div id="services" class="services">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2>Our Collections</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-camera-retro fa-3x"></i>
              <h3>Science Museum</h3>
                <h3>Aquarium</h3>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
			<i class="service-icon fa fa-camera fa-3x"></i>
              <h3>Mirror Gallery</h3>
                <h3>Colamine</h3>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-globe fa-3x"></i>
              <h3>Butterfly Park</h3>
                <h3>Aromatic Plant Garden</h3>
              <p></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /Services -->

    <!-- Portfolio -->
     <div id="portfolio" class="portfolio">
    <div class="container">
    <div class="row push50">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2>Our Gallery</h2>
			<h3>
			<span class="filter label label-default" data-filter="all">ALL</span>
	<span class="filter label label-default" data-filter="bw">Indian</span>
	<span class="filter label label-default" data-filter="nature">Imported</span>
	
	</h3>
            <hr>
          </div>
        </div>
		
		<div class="row">
		
		<div class="gallery">
		
    		  <ul id="Grid" class="gcontainer">
    		    <li class="col-md-4 col-sm-4 col-xs-12 mix bw portraits" data-cat="graphics">
              <a data-toggle="modal" data-target="#portrait1" class="mix-cover">
                  <img class="horizontal" src="img/back1.jpg" alt="placeholder">
      		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 1</span></span>
              </a>                
      		  </li>
    		    <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="graphics">
                <a data-toggle="modal" data-target="#portrait2" class="mix-cover">
                    <img class="horizontal" src="img/rsc.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 2</span></span>
                </a>                
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix nature" data-cat="nature">
                <a data-toggle="modal" data-target="#portrait3" class="mix-cover">
                    <img class="horizontal" src="img/img13.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 3</span></span>
        		    </a>
      		  </li>
      		  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portraits">
                <a data-toggle="modal" data-target="#portrait4" class="mix-cover">
                    <img class="horizontal" src="img/img14.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 4</span></span>
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portraits">
                <a data-toggle="modal" data-target="#portrait5" class="mix-cover">
                    <img class="horizontal" src="img/img15.jpg" alt="placeholder">
        		       <span class="overlay"><span class="valign"></span><span class="title">Aqua 4</span></span>
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix nature" data-cat="nature">
                <a data-toggle="modal" data-target="#portrait6" class="mix-cover">
                    <img class="horizontal" src="img/img14.jpg" alt="placeholder">
        		      <span class="overlay"><span class="valign"></span><span class="title">Aqua 5</span></span>
        		    </a>
      		  </li>
      		  <li class="col-md-4 col-sm-4 col-xs-12 mix portraits" data-cat="portrait">
                <a data-toggle="modal" data-target="#portrait7" class="mix-cover green">
                    <img class="vertical" src="img/img13.jpg" alt="portrait 4">
                  <span class="overlay"><span class="valign"></span><span class="title">Aqua 6</span></span>           
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix bw nature all" data-cat="portrait">
                <a data-toggle="modal" data-target="#portrait8" class="mix-cover green">
                    <img class="vertical" src="img/img15.jpg" alt="Forest">
                   <span class="overlay"><span class="valign"></span><span class="title">Aqua 7</span></span>                    
        		    </a>
      		  </li>
			  <li class="col-md-4 col-sm-4 col-xs-12 mix bw nature all" data-cat="bw">
                <a data-toggle="modal" data-target="#portrait19" class="mix-cover green">
                    <img class="vertical" src="img/img14.jpg" alt="Black and White">
                   <span class="overlay"><span class="valign"></span><span class="title">Aqua 8</span></span>                  
        		    </a>
      		  </li>
    		  </ul>   
			  
<!-- Load Photo in Modal -->			  
   <div class="modal fade" id="portrait1" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 1</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait1" src="img/back1.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="portrait2" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 2</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait2" src="img/rsc.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="portrait3" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title text-center">Portrait 3</h4>
      </div>
      <div class="modal-body">
          <img class="thumbnail" alt="Portrait3" src="img/back1.jpg"/>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->














<!-- /Load Photo in Modal -->	
		</div>	
      </div>
		</div>
      </div>
    <!-- /Portfolio -->
    <!-- Contact -->
    <div id="contact">
      <div class="container">
        <div class="row">
		
          <div class="col-md-1 col-md-offset-1">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14329.354514989252!2d91.8160587!3d26.1204997!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1324cdcc1795214b!2sSCIENCE%20MUSEUM!5e0!3m2!1sen!2sin!4v1628174370763!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
             <div class="col-md-5 col-md-offset-5">
		<img src="images/contact.JPG" width="450" height="450">
          </div>
        </div>
      </div>
    </div>
    <!-- /Contact -->
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 text-center">
           <h2>Thank You</h2>
           <em>Copyright &copy; 2021 Design By, Leena Deka</em>
          </div>
        </div>
      </div>
    </footer>
    <!-- /Footer -->
    <!-- Bootstrap core JavaScript -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-scrolltofixed-min.js"></script>
	<script src="js/jquery.vegas.js"></script>
	<script src="js/jquery.mixitup.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/bootstrap.js"></script>
	
<!-- Slideshow Background  -->
	<script>
$.vegas('slideshow', {
  delay:5000,
  backgrounds:[
     { src:'./img/back1.jpg', fade:3000 },
	 { src:'./img/rsc.jpg', fade:3000 }
   
	
   
  	
	   
  ]
})('overlay', {
src:'./img/1overlay.png'
});

	</script>
<!-- /Slideshow Background -->

<!-- Mixitup : Grid -->
    <script>
		$(function(){
    $('#Grid').mixitup();
      });
    </script>
<!-- /Mixitup : Grid -->	

    <!-- Custom JavaScript for Smooth Scrolling - Put in a custom JavaScript file to clean this up -->
    <script>
      $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
          if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
            || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
              $('html,body').animate({
                scrollTop: target.offset().top
              }, 1000);
              return false;
            }
          }
        });
      });
    </script>
<!-- Navbar -->
<script type="text/javascript">
$(document).ready(function() {
        $('#nav').scrollToFixed();
  });
    </script>
<!-- /Navbar-->
	
  </body>

</html>