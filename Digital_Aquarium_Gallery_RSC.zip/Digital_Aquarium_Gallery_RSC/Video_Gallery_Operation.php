<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       
include 'connection.php';
if(isset($_POST['save']))
{    

 $file1 = rand(1000,100000)."-".$_FILES['t3']['name'];
 $file_loc1 = $_FILES['t3']['tmp_name'];
 $file_size1 = $_FILES['t3']['size'];
 $file_type1 = $_FILES['t3']['type'];
 $folder="uploads/";
 $new_size1 = $file_size1/1024;  
 $new_file_name1 = strtolower($file1);
 $final_file1=str_replace(' ','-',$new_file_name1);
 
 
 extract($_POST);
if(move_uploaded_file($file_loc1,$folder.$final_file1))
 {
  $sql="INSERT INTO video_gallery values('$t1','$t2','$final_file1')";
mysqli_query($conn,$sql);
  ?>
<script>
alert('Video Uploaded Successfully');
window.location.href='Admin_Home.php?id=vg';
</script>
<?php
 }
else
 {
  ?>
<script>
alert('Error while Saving Details');
window.location.href='Admin_Home.php?id=vg';
</script>
<?php
 }
}


 if(isset($_GET['id']))
        {
            $id=$_GET['id'];
            $query=  mysqli_query($conn, "delete from video_gallery where v_no='$id'");
            if($query)
            {
             ?>
              <script>
                  alert("Record Deleted Successfully");
                 window.location.href='Admin_Home.php?id=vg';
              </script>
        <?php
            }
           else 
           {
        ?>
             <script>
                  alert("Error In Deleting Data");
                 window.location.href='Admin_Home.php?id=vg';
              </script> 
       <?php          
           } 
        }

?>

    </body>
</html>
