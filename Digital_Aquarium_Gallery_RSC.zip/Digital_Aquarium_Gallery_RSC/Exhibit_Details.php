<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <br>
        <h5 align="center" style="background-color:#0069d9;">Exhibit Details</h5>
         <?php
        include 'Connection.php';
        error_reporting(1);
         $t=mysqli_query($conn,"select max(exhibit_id) from exhibit");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }
          else
          {
              $v='Type/112';
          }
        
        ?>
        <form name="form1" action="" method="post">
            <table align="center">
                <tr>
                    <td>
                        <label for="t1">Exhibit Id</label><br>
                        <input type="text" name="t1" id="t1" size="40" value="<?php echo $v; ?>" readonly>
                    </td>
                </tr>
                 <tr>
                    <td>
                        <label for="t2">Scientific Name</label><br>
                        <input type="text" name="t2" id="t2" size="40" required>
                    </td>
                </tr>
                <tr>
                     <td>
                        <label for="t3">Class</label><br>
                        <input type="text" name="t3" id="t3" size="40" required>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t4">Phylum (Kingdom)</label><br>
                        <input type="text" name="t4" id="t4" size="40" required>
                    </td>
                </tr>
                 <tr>
                     <td>
                        <label for="t5">Found In</label><br>
                        <input type="text" name="t5" id="t5" size="40" required>
                    </td>
                </tr>
              
                 
                 <td colspan="2" align="center">
                        <input type="submit" class="btn btn-primary form-control" name="save" value="Save">
                    </td>
                </tr>
            </table>
        </form>
        
         <?php
    include 'Connection.php';
    error_reporting(1);
    extract($_POST);
    $temp= mysqli_query($conn, "select * from exhibit");
    ?>
        <table class="table" align="center" style="width:700px;">
            <thead>
            <tr>
                <th>Exhibit Id</th>
                 <th>Scientific Name</th>
                  <th>Class</th>
                  <th>Phylum</th>
                  <th>Found In</th>
                 
                   <th>Delete</th>
                  <th>Edit</th>
            </tr> </thead>
       <?php
        while($data= mysqli_fetch_array($temp))
        {
      ?>      
            <tr>
                <td><?php echo $data['exhibit_id'];  ?></td>
                <td><?php echo $data['e_name'];  ?></td>
                <td><?php echo $data['class'];  ?></td>
                <td><?php echo $data['phylum'];  ?></td>
                <td><?php echo $data['found'];  ?></td>
                
                <td><a href="Exhibit_Operation.php?id=<?php echo $data['exhibit_id'];  ?>" onclick="return confirm('Are You Sure..You Want to Delete Data Permanently');"><img src="delete.png" hight="20px" width="20px"></a></td>
                <td><a href="Exhibit_Update.php?id=<?php echo $data['exhibit_id'];  ?>"><img src="edit.png" hight="20px" width="20px"></a></td>
                
            </tr>  
            
     <?php       
        }
       
        
       ?>
        </table>
    
    <?php
    if(isset($_POST['save']))
    {
        extract($_POST);  
    $r= mysqli_query($conn, "insert into exhibit values('$t1','$t2','$t3','$t4','$t5')") or die("Error in Saving Data");
    if($r)
    {
     ?>
      <script>
          alert("Record Saved Successfully");
          window.location.href="Admin_Home.php?id=e";          
      </script>    
        
  <?php 
    }
    }
    ?>
    </body>
</html>
