<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <?php
    error_reporting(1);
     include 'Connection.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <title>Answer Entry Form</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    </head>
    <body style="background-color:lightcyan;">
         <div class="container">
            <h2>Answers Entry form</h2>
        <?php
         $t=mysqli_query($conn,"select max(ans_id) from answers");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }else
          {
              $v=1;
          }
          $op1=$v;
          $op2=$v+1;
          $op3=$v+2;
          $op4=$v+3;
          $src= mysqli_query($conn, "select max(q_id) from questions");
          $m= mysqli_fetch_array($src);
          $m1=$m[0];
          $q= mysqli_query($conn, "select * from questions where q_id='$m[0]]'");
          $ques= mysqli_fetch_array($q);       
        ?>
  
    <form action="" method="post">
    <div class="form-group">
        <label for="t3">Question</label>
        <input type="text" class="form-control"  name="t3" style="color: brown;" value=" <?php echo $ques['question']; ?>" readonly>
    </div>
              
    <div class="form-group">
        <label for="p1">Option 1 <h5 style="color: red;"><?php echo ' (Ans ID: '. $op1. ')'; ?></h5></label>
        <input type="text" class="form-control"  placeholder="Enter Option 1" name="p1" required="">
    </div>
    <div class="form-group">
      <label for="p2">Option 2 <h5 style="color: red;"><?php echo ' (Ans ID: '. $op2. ')'; ?></h5></label>
      <input type="text" class="form-control"  placeholder="Enter Option 2" name="p2" required="">
    </div>
        <div class="form-group">
      <label for="p3">Option 3 <h5 style="color: red;"><?php echo ' (Ans ID: '. $op3. ')'; ?></h5></label>
      <input type="text" class="form-control"  placeholder="Enter Option 3" name="p3" required="">
    </div>
        <div class="form-group">
      <label for="p4">Option 4 <h5 style="color: red;"><?php echo ' (Ans ID: '. $op4. ')'; ?></h5></label>
      <input type="text" class="form-control"  placeholder="Enter Option 4" name="p4" required="">
    </div>
       <div class="form-group">
      <label for="ansid">Select Correct Answer Id (Out of the above four)</label>
      <select name="ansid" required class="custom-select mb-3" required="">
          <option vlaue="">--Select--</option>
          <option values="<?php echo $op1; ?>"><?php echo $op1; ?></option>
          <option values="<?php echo $op2; ?>"><?php echo $op2; ?></option>
          <option values="<?php echo $op3; ?>"><?php echo $op3; ?></option>
          <option values="<?php echo $op4; ?>"><?php echo $op4; ?></option>
      </select> 
    </div>   
    <button type="submit" class="btn btn-primary" name="save">Submit</button>
  </form>
</div>

        <?php
        extract($_POST);
        if(isset($_POST['save']))
        {
            $r1= mysqli_query($conn, "insert into answers values('$op1','$p1','$m1')") or die("Error in Saving Data");
            $r2= mysqli_query($conn, "insert into answers values('$op2','$p2','$m1')") or die("Error in Saving Data");
            $r3= mysqli_query($conn, "insert into answers values('$op3','$p3','$m1')") or die("Error in Saving Data");
            $r4= mysqli_query($conn, "insert into answers values('$op4','$p4','$m1')") or die("Error in Saving Data");
            $r5= mysqli_query($conn, "update questions set ans_id='$ansid' where q_id='$m1'") or die("Error in Updating Data");
            if($r1 && $r2 && $r3 && $r4 && $r5)
            {
       ?>
        <script>
            alert("Saved Successfully");
            window.location.href="Admin_Home.php?id=q";
            
         </script>   
        <?php
            }
        }
        ?>
    </body>
</html>

