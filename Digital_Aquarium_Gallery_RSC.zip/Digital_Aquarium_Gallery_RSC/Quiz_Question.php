<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <?php
    error_reporting(1);
    include 'Connection.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <title>Question Entry</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <br>
        <br>
        <br>
         <div class="container">
            <h2>Question Entry form</h2>
        <?php
         $t=mysqli_query($conn,"select max(q_id) from questions");
          $row=  mysqli_fetch_array($t);
          if($row[0])
          {
              $v=++$row[0];
          }else
          {
              $v=1;
          }
        ?>
      
       
    <form action="" method="post">
    <div class="form-group">
      <label for="t1">Question No:</label>
      <input type="text"  id="t1" placeholder="Question No" name="t1" value="<?php echo $v; ?>" readonly>
    </div>
                        
    <div class="form-group">
      <label for="t2">Question</label>
      <input type="text"  id="t2" placeholder="Enter Question" name="t2" size="90">
    </div>
    
    <button type="submit" class="btn btn-primary" name="save">Submit</button>
  </form>
</div>

        <?php
        extract($_POST);
        $t3="0";
        if(isset($_POST['save']))
        {
            $r= mysqli_query($conn, "insert into questions values('$t1','$t2','$t3')") or die("Error in Saving Data");
            if($r)
            {
       ?>
        <script>
            alert("Saved Successfully");
            window.location.href="Admin_Home.php?id=ae";
            
         </script>   
        <?php
            }
        }
        ?>
    </body>
</html>
